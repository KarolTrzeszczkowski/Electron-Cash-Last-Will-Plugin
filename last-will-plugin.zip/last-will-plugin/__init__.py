from electroncash.i18n import _

fullname = 'last-will-plugin'
description = _('Plugin last-will-plugin')
available_for = ['qt']
